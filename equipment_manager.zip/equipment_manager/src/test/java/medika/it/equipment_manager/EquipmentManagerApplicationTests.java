package medika.it.equipment_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquipmentManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
