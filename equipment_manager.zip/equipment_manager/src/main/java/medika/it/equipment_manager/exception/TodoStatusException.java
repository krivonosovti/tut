package medika.it.equipment_manager.exception;

public class TodoStatusException extends Exception{
    public TodoStatusException (String message)
    {
        super(message);
    }
}
