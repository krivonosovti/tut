package medika.it.equipment_manager.repository;

import medika.it.equipment_manager.entity.SubdivisionEnity;
import org.springframework.data.repository.CrudRepository;

public interface SubdivisionRepo extends CrudRepository <SubdivisionEnity,Long> {
}
