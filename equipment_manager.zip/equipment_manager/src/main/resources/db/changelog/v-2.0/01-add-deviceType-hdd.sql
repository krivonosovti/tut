alter table device_type_entity
    add column hdd varchar(256)
;