alter table device_type_entity
    drop column hdd
;