alter table if exists device_type_entity
    drop constraint if exists FKb81sy00eseckf6vr6k17g256b
;
drop table if exists device_type_entity cascade
;