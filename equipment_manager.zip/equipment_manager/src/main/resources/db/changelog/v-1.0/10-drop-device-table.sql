alter table if exists device_entity
    drop constraint if exists FKqgx2q05mio3d8xa8kp9q6cd6h
;

drop table if exists device_entity cascade
;
