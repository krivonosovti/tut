alter table if exists user_entity
    drop constraint if exists FKk9mxikny0qk17weha6lhgs3v2
;
drop table user_entity
;