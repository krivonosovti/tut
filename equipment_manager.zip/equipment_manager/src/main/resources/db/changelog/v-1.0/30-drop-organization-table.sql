drop table if exists organization_entity cascade
;
