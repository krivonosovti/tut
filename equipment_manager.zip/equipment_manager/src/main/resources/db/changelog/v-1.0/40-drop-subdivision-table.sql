alter table if exists subdivision_enity
    drop constraint if exists FK6jl7kcbtqyd2e74styia012yk
;
drop table if exists subdivision_enity cascade
;